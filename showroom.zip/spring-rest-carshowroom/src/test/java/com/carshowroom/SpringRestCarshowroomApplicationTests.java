package com.carshowroom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestCarshowroomApplicationTests {

	@Test
	void contextLoads() {
	}

}
