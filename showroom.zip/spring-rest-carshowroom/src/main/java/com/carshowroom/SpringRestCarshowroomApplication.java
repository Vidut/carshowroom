package com.carshowroom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestCarshowroomApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestCarshowroomApplication.class, args);
	}

}
