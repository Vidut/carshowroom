package com.carshowroom.carNotFoundException;

public class CarException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;

	public CarException() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public CarException(String message) {
		super(message);
	}
	

}
